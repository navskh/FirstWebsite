<template>
	<footer>
		<h4>First webpage </h4>
	</footer>
</template>

<script>
export default {
	
}
</script>

<style scoped>
footer{border-top:1px solid #35495e; text-align:center; font-size:16px; color:#41b883; margin:100px 0 0 0;}
</style>